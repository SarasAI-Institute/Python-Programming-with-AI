"""Capstone solutions

Your solutions for the capstone. This is the only file you edit and submit.

- Write your code inside the functions below. Do not rename them.
- You may add your own helper functions.
- Keep any testing code under  if __name__ == "__main__":  at the bottom.
  Code outside functions runs whenever the file is loaded, and can break the
  board and the grading.
- To see your code on the board, run:  python students_run_test.py
"""

# Fill in your details. These are used to identify your submission.
Full_Name = ""
Enrolment_no = ""


# ---------------------------------------------------------------------------
# Rules for every level
#
# - Each move is one square: 'R' right (x + 1), 'L' left (x - 1),
#   'U' up (y + 1), 'D' down (y - 1).
# - Points are (x, y) tuples of whole numbers. They can be negative.
# - Return a list of moves, for example ['R', 'R', 'U'].
# - Use the fewest moves you can.
# - The ball must stay on the grid: the rectangle around every point in the
#   question. The ring of cells around it is a no-entry zone.
# - Your code is also graded on cases you cannot see. Each level says what is
#   always true for its cases. Your code must work for any case like that.
# ---------------------------------------------------------------------------


def level_1(start, end):
    """Level 1: Reach the end.

    Move the ball from start to end.

    Example: from (0, 0) to (2, 1), return ['R', 'R', 'U'].

    Always true: start and end are never the same point.
    """
    # Remove the line below and write your code here.
    return None


def level_2(start, passenger, end):
    """Level 2: Pick up a passenger.

    Drive from start to the passenger, then on to the end.

    Always true: there are no obstacles.
    """
    # Remove the line below and write your code here.
    return None


def level_3(start, end, rock):
    """Level 3: Rock in the field.

    A rock sits at the point `rock`. Reach the end without hitting it.

    Always true:
    - The rock is on the path that moves sideways first, then up or down.
    - Start and end are never in a straight line.
    - The rock is never on the start or the end.
    """
    # Remove the line below and write your code here.
    return None


def level_4(start, end, wall, gap):
    """Level 4: Wall near the start.

    `wall` is 'row' or 'column'. The wall fills that whole row (or column) of
    the grid, except for one gap at the point `gap`.

    Always true:
    - Start and end are at opposite corners of the grid.
    - The wall is in the row (or column) right next to the start.
    - The gap is at one end of the wall, in line with the start or the end.
    - For a row wall, start and end are at least two rows apart. For a column
      wall, they are at least two columns apart.
    """
    # Remove the line below and write your code here.
    return None


def level_5(start, stops, end):
    """Level 5: Delivery round.

    `stops` is a list of points, in no particular order. Visit every stop,
    then reach the end, in the fewest moves.

    Always true:
    - All the stops lie along one route from start to end, so you never need
      to step backwards.
    - There are no obstacles.
    """
    # Remove the line below and write your code here.
    return None


def level_6(start, passengers, end):
    """Level 6: Choose the best passenger.

    `passengers` is a list of points. Pick up just one of them, then reach the
    end. Choose the passenger that makes the whole trip shortest.

    Always true: there are no obstacles.
    """
    # Remove the line below and write your code here.
    return None


def level_7(start, end, river_y, bridge_x):
    """Level 7: River with a bridge.

    A river fills the whole row y = river_y, across the full width of the
    grid. The only dry cell in that row is the bridge at (bridge_x, river_y).

    Always true:
    - The river's row is between the start's row and the end's row, and is
      never the start's or the end's row.
    - The bridge can be anywhere along the river, even off to the side of
      both start and end.
    """
    # Remove the line below and write your code here.
    return None


def level_8(start, end, river_y, bridges):
    """Level 8: Choose the better bridge.

    Like Level 7, but `bridges` is a list of the bridges' x values. Use the
    bridge that gives the shorter trip.

    Always true: the same as Level 7, for every bridge.
    """
    # Remove the line below and write your code here.
    return None


def level_9(start, end, rivers):
    """Level 9: Several rivers.

    `rivers` is a list of (river_y, bridge_x) pairs. Each river fills its whole
    row except for its bridge. Cross them all and reach the end.

    Always true:
    - The rivers are listed in the order you meet them, going from start to end.
    - There is at least one dry row between any two rivers.
    - No river is on the start's row or the end's row.
    """
    # Remove the line below and write your code here.
    return None


def level_10(start, passenger, end, rocks):
    """Level 10: Passenger past the rocks.

    Pick up the passenger, then reach the end. `rocks` is a list of points.

    Always true:
    - One rock blocks the corner route to the passenger that goes sideways
      first, and another blocks the one that goes up or down first.
    - No rock is right next to the start or the passenger.
    - A route with the fewest moves exists for both parts of the trip.
    """
    # Remove the line below and write your code here.
    return None


if __name__ == "__main__":
    # You can test your functions here. This part does not affect grading.
    print(level_1((0, 0), (3, 3)))
